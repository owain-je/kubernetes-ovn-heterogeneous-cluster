Committers
----------

OVS committers are the people who have been granted access to push changes to
to the OVS git repository.  The responsibilities of an OVS committer are
documented in
[committer-responsibilities.md](./Documentation/committer-responsibilities.md).

The process for adding or removing committers is in
[committer-grant-revocation.md](./Documentation/committer-grant-revocation.md).

This is the current list of OVS committers:

    Alex Wang               ee07b291@gmail.com
    Andy Zhou               azhou@ovn.org
    Ansis Atteka            aatteka@nicira.com
    Ben Pfaff               blp@ovn.org
    Daniele Di Proietto     daniele.di.proietto@gmail.com
    Ethan J. Jackson        ejj@eecs.berkeley.edu
    Gurucharan Shetty       guru@ovn.org
    Jarno Rajahalme         jarno@ovn.org
    Jesse Gross             jesse@kernel.org
    Joe Stringer            joe@ovn.org
    Justin Pettit           jpettit@ovn.org
    Pravin B Shelar         pshelar@nicira.com
    Russell Bryant          russell@ovn.org
    Simon Horman            horms@ovn.org
    Thomas Graf             tgraf@noironetworks.com
    YAMAMOTO Takashi        yamamoto@midokura.com
